import { SelectionModel } from '@angular/cdk/collections';
import {
  AfterViewInit,
  Component,
  Inject,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ClientDataService } from 'src/app/services/client-data.service';

@Component({
  selector: 'app-task-detail',
  templateUrl: './task-detail.component.html',
  styleUrls: ['./task-detail.component.css'],
})
export class TaskDetailComponent implements OnInit, AfterViewInit {
  fileDisplayedColumns: string[] = ['select', 'filename', 'filesize'];
  fileDataSource = new MatTableDataSource<any>();
  selection = new SelectionModel<any>(true, []);

  transfersDisplayedColumns: string[] = [
    'filename',
    'filesize',
    'target',
    'previous',
    'warning',
    'action',
  ];
  transfersDataSource = new MatTableDataSource<any>();
  transfersSelection = new SelectionModel<any>(true, []);
  pageSize: number = 10;
  params: any;
  taskDetails: any;
  selectedRadio: string = '';
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;

  isAddClicked: boolean = false;
  TaskRadio: string[] = [
    'Complete task and keep bundle process open for further transfers',
    'Complete task and finish bundle process',
  ];
  selectedTarget: any;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<TaskDetailComponent>,
    private taskService: ClientDataService
  ) {
    this.params = data;
  }

  ngOnInit(): void {
    this.getTaskDetails();
  }

  ngAfterViewInit() {
    this.fileDataSource.paginator = this.paginator;
  }

  getTaskDetails() {
    this.taskDetails = {
      clientName: 'Edward Jones',
      clientCode: 'EDJ',
      clientNumber: 'C062',
      avosTaskId: 0,
      avosUserId: null,
      imageBundleFullPath:
        'C:\\Users\\AnkinapalliR\\development\\TaxFileTransfer\\br-tax-transfer-acceptance-tests\\src\\test\\resources\\PROD.BIOS.C062.OUT6833.RPTS.D1181201.T092700.0601.PROOF.zip',
      imageBundle:
        'PROD.BIOS.C062.OUT6833.RPTS.D1181201.T092700.0601.PROOF.zip',
      mailDate: null,
      targets: {
        target: [
          {
            destination: null,
            environment: null,
            id: 'Client-qa',
            combineOutput: true,
            imageFileExtensionCase: 'lower',
          },
          {
            destination: null,
            environment: null,
            id: 'Client-prod',
            combineOutput: true,
            imageFileExtensionCase: 'lower',
          },
        ],
      },
      status: 'Claimed',
      fileDefinitions: {
        fileDefinition: [
          {
            fileName:
              'PROD.BIOS.C062.OUT6833.RPTS.D1181201.T092700.0601.PROOF.AFP',
            fileNameMask: null,
            expectedFlag: false,
            transferredBeforeFlag: false,
            fileSize: 2311528,
            fileSizeDisplay: '2mb',
            possibleTargets: {
              possibleTarget: [
                {
                  targetId: 'Client-prod',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'warning',
                },
                {
                  targetId: 'Client-qa',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'normal',
                },
              ],
            },
          },
          {
            fileName:
              'PROD.BIOS.C062.OUT6833.RPTS.D1181204.T092700.0600.PROOF.AFP',
            fileNameMask: null,
            expectedFlag: false,
            transferredBeforeFlag: false,
            fileSize: 2311528,
            fileSizeDisplay: '2mb',
            possibleTargets: {
              possibleTarget: [
                {
                  targetId: 'Client-prod',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'warning',
                },
                {
                  targetId: 'Client-qa',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'normal',
                },
              ],
            },
          },
          {
            fileName:
              'PROD.BIOS.C062.OUT6833.RPTS.D1181204.T092700.0602.PROOF.AFP',
            fileNameMask: null,
            expectedFlag: false,
            transferredBeforeFlag: false,
            fileSize: 2311528,
            fileSizeDisplay: '2mb',
            possibleTargets: {
              possibleTarget: [
                {
                  targetId: 'Client-prod',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'warning',
                },
                {
                  targetId: 'Client-qa',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'normal',
                },
              ],
            },
          },
          {
            fileName:
              'PROD.BIOS.C062.OUT6833.RPTS.D1181201.T092700.0601.PROOF.AFP',
            fileNameMask: null,
            expectedFlag: false,
            transferredBeforeFlag: false,
            fileSize: 2311528,
            fileSizeDisplay: '2mb',
            possibleTargets: {
              possibleTarget: [
                {
                  targetId: 'Client-prod',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'warning',
                },
                {
                  targetId: 'Client-qa',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'normal',
                },
              ],
            },
          },
          {
            fileName:
              'PROD.BIOS.C062.OUT6833.RPTS.D1181204.T092700.0600.PROOF.AFP',
            fileNameMask: null,
            expectedFlag: false,
            transferredBeforeFlag: false,
            fileSize: 2311528,
            fileSizeDisplay: '2mb',
            possibleTargets: {
              possibleTarget: [
                {
                  targetId: 'Client-prod',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'warning',
                },
                {
                  targetId: 'Client-qa',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'normal',
                },
              ],
            },
          },
          {
            fileName:
              'PROD.BIOS.C062.OUT6833.RPTS.D1181204.T092700.0602.PROOF.AFP',
            fileNameMask: null,
            expectedFlag: false,
            transferredBeforeFlag: false,
            fileSize: 2311528,
            fileSizeDisplay: '2mb',
            possibleTargets: {
              possibleTarget: [
                {
                  targetId: 'Client-prod',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'warning',
                },
                {
                  targetId: 'Client-qa',
                  transferFlag: false,
                  transferDateTime: null,
                  manualTransferFlag: null,
                  manualTransferAvosTaskId: null,
                  transferErrorReason: null,
                  confirmationLevel: 'normal',
                },
              ],
            },
          },
        ],
      },
    };

    this.fileDataSource = new MatTableDataSource<any>(
      this.taskDetails.fileDefinitions.fileDefinition
    );

    // this.taskService
    //   .getTaskDetails(this.params.taskId, this.params.clientCode)
    //   .subscribe((res: any) => {
    //     this.taskDetails = res;
    //     this.fileDataSource = new MatTableDataSource<any>(
    //       this.taskDetails.fileDefinitions.fileDefinition
    //     );
    //   });
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.fileDataSource.data.length;
    return numSelected === numRows;
  }

  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.fileDataSource.data);
  }

  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.position + 1
    }`;
  }

  isAllTransferSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.fileDataSource.data.length;
    return numSelected === numRows;
  }

  toggleAllTransferRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.fileDataSource.data);
  }

  transfersCheckboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${
      row.position + 1
    }`;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  add() {
    this.isAddClicked = true;
    this.selection.selected.forEach((obj: any) => {
      obj.target = this.selectedTarget;
    });

    this.transfersDataSource = new MatTableDataSource<any>(
      this.selection.selected
    );

    this.selection.clear();
    this.selectedTarget = [];
  }

  onTargetChange(event: any) {
    this.selectedTarget = event.value.toString();
  }

  removeTransfer(index: any) {
    console.log(this.transfersDataSource.data, index);
    let filterData: any;
    if (this.transfersDataSource.data.length == 1) {
      filterData = [];
    } else {
       filterData = this.transfersDataSource.data.splice(index, 1);
    }
    console.log(filterData);
    this.transfersDataSource = new MatTableDataSource<any>(filterData);
  }

  complete() {
    const userDetails: any = localStorage.getItem('userDetails');
    const payLoad = {
      id: this.params.taskId,
      userName: JSON.parse(userDetails).userName,
      status: this.selectedRadio,
      targetData: this.transfersDataSource.data,
      imageBundlePath: this.taskDetails.imageBundle
    };

    console.log(payLoad);
    
  }
}
